package com.example.crudrapido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudrapidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudrapidoApplication.class, args);
	}

}
